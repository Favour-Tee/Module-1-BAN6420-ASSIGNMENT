install.packages("dplyr")

library(dplyr)

workers <- data.frame(
  id = integer(),
  salary = numeric(),
  gender = character(),
  level = character(),
  stringsAsFactors = FALSE
)

set.seed(42) 
for (i in 1:400) {
  tryCatch({
    
    salary <- sample(5000:30000, 1) 
    gender <- sample(c("Male", "Female"), 1) 
    level <- "Unassigned"  
    
    if (salary > 10000 & salary < 20000) {
      level <- "A1"
    } else if (salary > 7500 & salary < 30000 & gender == "Female") {
      level <- "A5-F"
    }
    
    workers <- workers %>%
      add_row(id = i, salary = salary, gender = gender, level = level)
  }, error = function(e) {
    cat("Error occurred for worker", i, ":", e$message, "\n")
  })
}

options(max.print = 10000)

print(head(workers, 400))


